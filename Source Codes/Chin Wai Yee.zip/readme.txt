Practical Group: P24
Practical Session: Thursday, 8AM - 10AM
Tutor: Mr. Tou Jing Yi

Group Member 1:

Name: Chin Wai Yee
Student ID: 2103370
Course: CS

Group Member 2:

Name: Ooi Jun Lin
Student ID: 2103905
Course: IA

Group Member 3:

Name: Chun Cheng long
Student ID: 2004768
Course: CN


Group Member 4:

Name: Fong Yu Qi
Student ID: 2003659
Course: IA

Group Member 5:

Name: Hew Yen Ming
Student ID: 1800230
Course: IA
